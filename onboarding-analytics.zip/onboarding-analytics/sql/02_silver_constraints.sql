/*=============================================================
    02_silver_constraints.sql
    PART 1 - PRIMARY KEYS
=============================================================*/

-------------------------------------------------------------
-- Drop existing Primary Keys (Safe Re-run)
-------------------------------------------------------------

ALTER TABLE silver.customer
ADD CONSTRAINT customer_pk
PRIMARY KEY (customer_id);

ALTER TABLE silver.customer_address
ADD CONSTRAINT customer_address_pk
PRIMARY KEY (address_id);

ALTER TABLE silver.onboarding_application
ADD CONSTRAINT onboarding_application_pk
PRIMARY KEY (application_id);

ALTER TABLE silver.onboarding_step_master
ADD CONSTRAINT onboarding_step_master_pk
PRIMARY KEY (step_id);

ALTER TABLE silver.onboarding_step_status
ADD CONSTRAINT onboarding_step_status_pk
PRIMARY KEY (step_status_id);

ALTER TABLE silver.customer_document
ADD CONSTRAINT customer_document_pk
PRIMARY KEY (document_id);

ALTER TABLE silver.customer_bank
ADD CONSTRAINT customer_bank_pk
PRIMARY KEY (bank_id);

ALTER TABLE silver.customer_verification_status
ADD CONSTRAINT customer_verification_status_pk
PRIMARY KEY (verification_id);

ALTER TABLE silver.compliance_review
ADD CONSTRAINT compliance_review_pk
PRIMARY KEY (review_id);

ALTER TABLE silver.activation
ADD CONSTRAINT activation_pk
PRIMARY KEY (activation_id);

ALTER TABLE silver.customer_event
ADD CONSTRAINT customer_event_pk
PRIMARY KEY (event_id);

/*=============================================================
PRIMARY KEYS
=============================================================*/

-------------------------------------------------------------
-- CUSTOMER
-------------------------------------------------------------
ALTER TABLE silver.customer
DROP CONSTRAINT IF EXISTS customer_pk CASCADE;

ALTER TABLE silver.customer
ADD CONSTRAINT customer_pk
PRIMARY KEY (customer_id);

-------------------------------------------------------------
-- CUSTOMER ADDRESS
-------------------------------------------------------------
ALTER TABLE silver.customer_address
DROP CONSTRAINT IF EXISTS customer_address_pk CASCADE;

ALTER TABLE silver.customer_address
ADD CONSTRAINT customer_address_pk
PRIMARY KEY (address_id);

-------------------------------------------------------------
-- ONBOARDING APPLICATION
-------------------------------------------------------------
ALTER TABLE silver.onboarding_application
DROP CONSTRAINT IF EXISTS onboarding_application_pk CASCADE;

ALTER TABLE silver.onboarding_application
ADD CONSTRAINT onboarding_application_pk
PRIMARY KEY (application_id);

-------------------------------------------------------------
-- STEP MASTER
-------------------------------------------------------------
ALTER TABLE silver.onboarding_step_master
DROP CONSTRAINT IF EXISTS onboarding_step_master_pk CASCADE;

ALTER TABLE silver.onboarding_step_master
ADD CONSTRAINT onboarding_step_master_pk
PRIMARY KEY (step_id);

-------------------------------------------------------------
-- STEP STATUS
-------------------------------------------------------------
ALTER TABLE silver.onboarding_step_status
DROP CONSTRAINT IF EXISTS onboarding_step_status_pk CASCADE;

ALTER TABLE silver.onboarding_step_status
ADD CONSTRAINT onboarding_step_status_pk
PRIMARY KEY (step_status_id);

-------------------------------------------------------------
-- CUSTOMER DOCUMENT
-------------------------------------------------------------
ALTER TABLE silver.customer_document
DROP CONSTRAINT IF EXISTS customer_document_pk CASCADE;

ALTER TABLE silver.customer_document
ADD CONSTRAINT customer_document_pk
PRIMARY KEY (document_id);

-------------------------------------------------------------
-- CUSTOMER BANK
-------------------------------------------------------------
ALTER TABLE silver.customer_bank
DROP CONSTRAINT IF EXISTS customer_bank_pk CASCADE;

ALTER TABLE silver.customer_bank
ADD CONSTRAINT customer_bank_pk
PRIMARY KEY (bank_id);

-------------------------------------------------------------
-- CUSTOMER VERIFICATION STATUS
-------------------------------------------------------------
ALTER TABLE silver.customer_verification_status
DROP CONSTRAINT IF EXISTS customer_verification_status_pk CASCADE;

ALTER TABLE silver.customer_verification_status
ADD CONSTRAINT customer_verification_status_pk
PRIMARY KEY (verification_id);

-------------------------------------------------------------
-- COMPLIANCE REVIEW
-------------------------------------------------------------
ALTER TABLE silver.compliance_review
DROP CONSTRAINT IF EXISTS compliance_review_pk CASCADE;

ALTER TABLE silver.compliance_review
ADD CONSTRAINT compliance_review_pk
PRIMARY KEY (review_id);

-------------------------------------------------------------
-- ACTIVATION
-------------------------------------------------------------
ALTER TABLE silver.activation
DROP CONSTRAINT IF EXISTS activation_pk CASCADE;

ALTER TABLE silver.activation
ADD CONSTRAINT activation_pk
PRIMARY KEY (activation_id);

-------------------------------------------------------------
-- CUSTOMER EVENT
-------------------------------------------------------------
ALTER TABLE silver.customer_event
DROP CONSTRAINT IF EXISTS customer_event_pk CASCADE;

ALTER TABLE silver.customer_event
ADD CONSTRAINT customer_event_pk
PRIMARY KEY (event_id);


/*=============================================================
FOREIGN KEYS
=============================================================*/

-------------------------------------------------------------
-- Drop Existing FKs (Safe Re-run)
-------------------------------------------------------------

ALTER TABLE silver.customer_address
DROP CONSTRAINT IF EXISTS fk_customer_address_customer CASCADE;

ALTER TABLE silver.onboarding_application
DROP CONSTRAINT IF EXISTS fk_application_customer CASCADE;

ALTER TABLE silver.onboarding_step_status
DROP CONSTRAINT IF EXISTS fk_stepstatus_application CASCADE;

ALTER TABLE silver.onboarding_step_status
DROP CONSTRAINT IF EXISTS fk_stepstatus_stepmaster CASCADE;

ALTER TABLE silver.customer_document
DROP CONSTRAINT IF EXISTS fk_document_application CASCADE;

ALTER TABLE silver.customer_bank
DROP CONSTRAINT IF EXISTS fk_bank_application CASCADE;

ALTER TABLE silver.customer_verification_status
DROP CONSTRAINT IF EXISTS fk_verification_application CASCADE;

ALTER TABLE silver.compliance_review
DROP CONSTRAINT IF EXISTS fk_review_application CASCADE;

ALTER TABLE silver.activation
DROP CONSTRAINT IF EXISTS fk_activation_application CASCADE;

ALTER TABLE silver.customer_event
DROP CONSTRAINT IF EXISTS fk_event_customer CASCADE;

ALTER TABLE silver.customer_event
DROP CONSTRAINT IF EXISTS fk_event_application CASCADE;

-------------------------------------------------------------
-- CUSTOMER ADDRESS
-------------------------------------------------------------

ALTER TABLE silver.customer_address
ADD CONSTRAINT fk_customer_address_customer
FOREIGN KEY (customer_id)
REFERENCES silver.customer(customer_id);

-------------------------------------------------------------
-- APPLICATION
-------------------------------------------------------------

ALTER TABLE silver.onboarding_application
ADD CONSTRAINT fk_application_customer
FOREIGN KEY (customer_id)
REFERENCES silver.customer(customer_id);

-------------------------------------------------------------
-- STEP STATUS
-------------------------------------------------------------

ALTER TABLE silver.onboarding_step_status
ADD CONSTRAINT fk_stepstatus_application
FOREIGN KEY (application_id)
REFERENCES silver.onboarding_application(application_id);

ALTER TABLE silver.onboarding_step_status
ADD CONSTRAINT fk_stepstatus_stepmaster
FOREIGN KEY (step_id)
REFERENCES silver.onboarding_step_master(step_id);

-------------------------------------------------------------
-- DOCUMENT
-------------------------------------------------------------

ALTER TABLE silver.customer_document
ADD CONSTRAINT fk_document_application
FOREIGN KEY (application_id)
REFERENCES silver.onboarding_application(application_id);

-------------------------------------------------------------
-- BANK
-------------------------------------------------------------

ALTER TABLE silver.customer_bank
ADD CONSTRAINT fk_bank_application
FOREIGN KEY (application_id)
REFERENCES silver.onboarding_application(application_id);

-------------------------------------------------------------
-- CUSTOMER VERIFICATION STATUS
-------------------------------------------------------------

ALTER TABLE silver.customer_verification_status
ADD CONSTRAINT fk_verification_application
FOREIGN KEY (application_id)
REFERENCES silver.onboarding_application(application_id);

-------------------------------------------------------------
-- COMPLIANCE REVIEW
-------------------------------------------------------------

ALTER TABLE silver.compliance_review
ADD CONSTRAINT fk_review_application
FOREIGN KEY (application_id)
REFERENCES silver.onboarding_application(application_id);

-------------------------------------------------------------
-- ACTIVATION
-------------------------------------------------------------

ALTER TABLE silver.activation
ADD CONSTRAINT fk_activation_application
FOREIGN KEY (application_id)
REFERENCES silver.onboarding_application(application_id);

-------------------------------------------------------------
-- CUSTOMER EVENT
-------------------------------------------------------------

ALTER TABLE silver.customer_event
ADD CONSTRAINT fk_event_customer
FOREIGN KEY (customer_id)
REFERENCES silver.customer(customer_id);

ALTER TABLE silver.customer_event
ADD CONSTRAINT fk_event_application
FOREIGN KEY (application_id)
REFERENCES silver.onboarding_application(application_id);

