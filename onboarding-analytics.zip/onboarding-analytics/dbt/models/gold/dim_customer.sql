{{ config(
    materialized='table'
) }}

SELECT

    c.customer_id,

    c.full_name,

    c.mobile_number,

    c.email,

    c.gender,

    c.dob,

    EXTRACT(YEAR FROM AGE(CURRENT_DATE,c.dob)) AS age,

    c.customer_status,

    c.created_date,

    a.city,

    a.district,

    a.state,

    a.pincode,

    a.country

FROM {{ source('silver','customer') }} c

LEFT JOIN {{ source('silver','customer_address') }} a
ON c.customer_id=a.customer_id