{{ config(
    materialized='table'
) }}

SELECT DISTINCT

source_channel

FROM {{ source('silver','onboarding_application') }}

ORDER BY source_channel