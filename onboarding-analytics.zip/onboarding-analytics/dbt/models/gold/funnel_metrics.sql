{{ config(materialized='table') }}

SELECT
'Applications Started' AS stage,
COUNT(*) AS applications,
1 AS stage_order

FROM {{ ref('fact_onboarding') }}

UNION ALL

SELECT
'Approved',
SUM(approved_flag),
2

FROM {{ ref('fact_onboarding') }}

UNION ALL

SELECT
'Activated',
SUM(activated_flag),
3

FROM {{ ref('fact_onboarding') }}