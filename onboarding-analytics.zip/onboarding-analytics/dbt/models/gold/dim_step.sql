{{ config(
    materialized='table'
) }}

SELECT

step_id,

step_name,

step_sequence,

mandatory_flag

FROM {{ source('silver','onboarding_step_master') }}

ORDER BY step_sequence