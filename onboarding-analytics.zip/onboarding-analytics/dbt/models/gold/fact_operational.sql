{{ config(materialized='table') }}

SELECT

a.application_id,

a.application_status,

cv.overall_status,

cr.decision,

CASE
WHEN a.application_status='Pending'
THEN 1 ELSE 0
END AS pending_application,

CASE
WHEN cv.overall_status='Pending'
THEN 1 ELSE 0
END AS pending_kyc,

CASE
WHEN cr.decision IS NULL
THEN 1 ELSE 0
END AS pending_review,

CASE
WHEN a.application_status='Rejected'
THEN 1 ELSE 0
END AS rejected_application

FROM {{ source('silver','onboarding_application') }} a

LEFT JOIN {{ source('silver','customer_verification_status') }} cv

ON a.application_id=cv.application_id

LEFT JOIN {{ source('silver','compliance_review') }} cr

ON a.application_id=cr.application_id