{{ config(materialized='table') }}

SELECT

a.application_id,

a.customer_id,

a.source_channel,

DATE(application_start_time) AS application_date,

a.application_start_time,

a.application_end_time,

a.application_status,

a.rejection_reason,

EXTRACT(EPOCH FROM
(a.application_end_time-a.application_start_time))/60
AS onboarding_minutes,

CASE
WHEN a.application_status IN ('Approved','Activated')
THEN 1
ELSE 0
END AS completed_flag,

CASE
WHEN cr.decision='Approved'
THEN 1 ELSE 0
END AS approved_flag,

CASE
WHEN act.activation_status='Activated'
THEN 1 ELSE 0
END AS activated_flag

FROM {{ source('silver','onboarding_application') }} a

LEFT JOIN {{ source('silver','compliance_review') }} cr
ON a.application_id=cr.application_id

LEFT JOIN {{ source('silver','activation') }} act
ON a.application_id=act.application_id