{{ config(materialized='table') }}

SELECT

ss.step_status_id,

ss.application_id,

sm.step_name,

sm.step_sequence,

ss.status,

ss.start_time,

ss.end_time,

EXTRACT(EPOCH FROM
(ss.end_time-ss.start_time))/60
AS step_duration_minutes

FROM {{ source('silver','onboarding_step_status') }} ss

JOIN {{ source('silver','onboarding_step_master') }} sm

ON ss.step_id=sm.step_id