{{ config(
    materialized='table'
) }}

SELECT DISTINCT

DATE(application_start_time) AS calendar_date,

EXTRACT(DAY FROM application_start_time) AS day_number,

EXTRACT(MONTH FROM application_start_time) AS month_number,

TO_CHAR(application_start_time,'Month') AS month_name,

EXTRACT(QUARTER FROM application_start_time) AS quarter,

EXTRACT(YEAR FROM application_start_time) AS year,

EXTRACT(WEEK FROM application_start_time) AS week_number

FROM {{ source('silver','onboarding_application') }}

ORDER BY calendar_date