{{ config(materialized='table') }}

SELECT

activation_id,

application_id,

activation_status,

activation_time,

trading_enabled,

remarks

FROM {{ source('silver','activation') }}