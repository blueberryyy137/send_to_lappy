import sys
import re

from pyspark.context import SparkContext

from pyspark.sql import SparkSession

from pyspark.sql.functions import (
    length,
    col,
    trim,
    when,
    upper,
    lower,
    initcap,
    regexp_replace,
    regexp_extract,
    to_timestamp,
    to_date,
    current_timestamp,
    lit,
    row_number
)

from pyspark.sql.window import Window

from pyspark.sql.types import *

from awsglue.context import GlueContext
from awsglue.job import Job

###########################################################
# Spark / Glue Initialization
###########################################################

sc = SparkContext()

glueContext = GlueContext(sc)

spark = glueContext.spark_session

job = Job(glueContext)

###########################################################
# PostgreSQL Configuration
###########################################################

JDBC_URL = (
    "jdbc:postgresql://"
    "onboarding-postgres.cpckkgcwoy32.ap-south-1.rds.amazonaws.com:5432/"
    "onboarding_analytics_db"
)

DB_USER = "postgres"

DB_PASSWORD = "Incedo123"

BRONZE_SCHEMA = "bronze"

SILVER_SCHEMA = "silver"

###########################################################
# Bronze Tables
###########################################################

TABLES = {

    "customer": "customer",

    "customer_address": "customer_address",

    "onboarding_application": "onboarding_application",

    "onboarding_step_master": "onboarding_step_master",

    "onboarding_step_status": "onboarding_step_status",

    "customer_document": "customer_document",

    "customer_bank": "customer_bank",

    "customer_verification_status": "customer_verification_status",

    "compliance_review": "compliance_review",

    "activation": "activation",

    "customer_event": "customer_event"

}

print("===========================================")
print(" Bronze --> Silver ETL Started ")
print("===========================================")

# ============================================================
# COMMON UTILITY FUNCTIONS
# ============================================================

from pyspark.sql.functions import (
    col,
    trim,
    lower,
    upper,
    initcap,
    regexp_replace,
    when,
    to_date,
    to_timestamp,
    current_timestamp,
    row_number,
    monotonically_increasing_id
)

from pyspark.sql.window import Window


# ------------------------------------------------------------
# Remove leading / trailing spaces from every string column
# ------------------------------------------------------------
def trim_all_strings(df):

    for c, t in df.dtypes:
        if t == "string":
            df = df.withColumn(c, trim(col(c)))

    return df


# ------------------------------------------------------------
# Replace empty strings with NULL
# ------------------------------------------------------------
def empty_to_null(df):

    for c, t in df.dtypes:
        if t == "string":
            df = df.withColumn(
                c,
                when(trim(col(c)) == "", None).otherwise(col(c))
            )

    return df


# ------------------------------------------------------------
# Standardize gender values
# ------------------------------------------------------------
def standardize_gender(df):

    if "gender" not in df.columns:
        return df

    return (
        df.withColumn(
            "gender",
            when(lower(col("gender")) == "male", "Male")
            .when(lower(col("gender")) == "female", "Female")
            .when(lower(col("gender")) == "other", "Other")
            .otherwise(None)
        )
    )


# ------------------------------------------------------------
# Standardize Country
# india
# INDIA
# India
#  -> India
# ------------------------------------------------------------
def standardize_country(df):

    if "country" not in df.columns:
        return df

    return df.withColumn(
        "country",
        initcap(lower(col("country")))
    )


# ------------------------------------------------------------
# Clean mobile numbers
# +91xxxxxxxxxx
# 91xxxxxxxxxx
# xxxxxxxxxx
# ------------------------------------------------------------
def clean_mobile(df):

    if "mobile_number" not in df.columns:
        return df

    df = df.withColumn(
        "mobile_number",
        regexp_replace(col("mobile_number"), r"\D", "")
    )

    df = df.withColumn(
        "mobile_number",
        regexp_replace(col("mobile_number"), "^91", "")
    )

    return df


# ------------------------------------------------------------
# Lowercase Email IDs
# ------------------------------------------------------------
def clean_email(df):

    if "email" not in df.columns:
        return df

    return df.withColumn(
        "email",
        lower(col("email"))
    )


# ------------------------------------------------------------
# Add ETL Timestamp
# ------------------------------------------------------------
def add_etl_timestamp(df):

    return df.withColumn(
        "etl_processed_timestamp",
        current_timestamp()
    )


# ------------------------------------------------------------
# Read Bronze Table
# ------------------------------------------------------------
def read_bronze(table_name):

    return (
        spark.read
        .format("jdbc")
        .option("url", JDBC_URL)
        .option("driver", "org.postgresql.Driver")
        .option("dbtable", f"bronze.{table_name}")
        .option("user", DB_USER)
        .option("password", DB_PASSWORD)
        .load()
    )


# ------------------------------------------------------------
# Write Silver Table
# ------------------------------------------------------------
def write_silver(df, table_name):

    (
        df.write
        .format("jdbc")
        .option("url", JDBC_URL)
        .option("driver", "org.postgresql.Driver")
        .option("dbtable", f"silver.{table_name}")
        .option("user", DB_USER)
        .option("password", DB_PASSWORD)
        .mode("overwrite")
        .save()
    )

    print(f"Loaded Silver Table : {table_name}")

# ============================================================
# CUSTOMER
# ============================================================

print("Transforming customer...")

customer = read_bronze("customer")

customer = (

    customer

    .dropDuplicates(["customer_id"])

    .withColumn(
        "full_name",
        initcap(trim(col("full_name")))
    )

    .withColumn(
        "gender",
        when(
            lower(col("gender")).isin("male","m"),
            "Male"
        )
        .when(
            lower(col("gender")).isin("female","f"),
            "Female"
        )
        .when(
            lower(col("gender"))=="other",
            "Other"
        )
        .otherwise(None)
    )

    .withColumn(
        "email",
        lower(trim(col("email")))
    )

    .withColumn(
        "mobile_number",
        regexp_replace(
            col("mobile_number"),
            "[^0-9]",
            ""
        )
    )

    .withColumn(
        "customer_status",
        initcap(trim(col("customer_status")))
    )

    .withColumn(
        "dob",
        to_date("dob")
    )

    .withColumn(
        "created_date",
        to_timestamp("created_date")
    )

    .withColumn(
        "silver_load_timestamp",
        current_timestamp()
    )

)

write_silver(customer,"customer")

# ============================================================
# CUSTOMER_ADDRESS
# ============================================================

print("Transforming customer_address...")

customer_address = read_bronze("customer_address")

customer_address = (

    customer_address

    .dropDuplicates(["address_id"])

    .withColumn(
        "address_type",
        initcap(trim(col("address_type")))
    )

    .withColumn(
        "city",
        initcap(trim(col("city")))
    )

    .withColumn(
        "state",
        initcap(trim(col("state")))
    )

    .withColumn(
        "country",
        when(
            lower(trim(col("country"))) == "india",
            "India"
        ).otherwise(initcap(trim(col("country"))))
    )

    .withColumn(
        "pincode",
        regexp_replace(col("pincode"), "[^0-9]", "")
    )

    .withColumn(
        "pincode",
        when(
            length(col("pincode")) == 6,
            col("pincode")
        ).otherwise(None)
    )

    .withColumn(
        "created_at",
        to_timestamp("created_at")
    )

    .withColumn(
        "updated_at",
        to_timestamp("updated_at")
    )

    .withColumn(
        "silver_load_timestamp",
        current_timestamp()
    )

)

write_silver(customer_address, "customer_address")

# ============================================================
# ONBOARDING_APPLICATION
# ============================================================

print("Transforming onboarding_application...")

application = read_bronze("onboarding_application")

application = (

    application

    .dropDuplicates(["application_id"])

    .withColumn(
        "application_status",
        initcap(trim(col("application_status")))
    )
    
    .withColumn(
        "application_start_time",
        to_timestamp("application_start_time")
    )
    
    .withColumn(
        "application_end_time",
        to_timestamp("application_end_time")
    )

    .withColumn(
        "application_version",
        col("application_version").cast("int")
    )

    .withColumn(
        "created_at",
        to_timestamp("created_at")
    )

    .withColumn(
        "updated_at",
        to_timestamp("updated_at")
    )

    .withColumn(
        "created_at",
        when(
            col("created_at").isNull(),
            col("updated_at")
        ).otherwise(col("created_at"))
    )

    .withColumn(
        "customer_id",
        trim(col("customer_id"))
    )

    .withColumn(
        "silver_load_timestamp",
        current_timestamp()
    )

)

write_silver(application, "onboarding_application")

# ============================================================
# ONBOARDING_STEP_MASTER
# ============================================================

print("Transforming onboarding_step_master...")

step_master = read_bronze("onboarding_step_master")

step_master = (

    step_master

    .dropDuplicates(["step_id"])

    .withColumn(
        "step_name",
        initcap(trim(col("step_name")))
    )

    .withColumn(
        "step_sequence",
        col("step_sequence").cast("int")
    )

    .withColumn(
        "mandatory_flag",
        when(
            lower(col("mandatory_flag")).isin("true","yes","1"),
            True
        ).otherwise(False)
    )

    .withColumn(
        "silver_load_timestamp",
        current_timestamp()
    )

)

write_silver(step_master,"onboarding_step_master")

# ============================================================
# ONBOARDING_STEP_STATUS
# ============================================================

print("Transforming onboarding_step_status...")

step_status = read_bronze("onboarding_step_status")

step_status = (

    step_status

    .dropDuplicates(["step_status_id"])

    .withColumn(
        "status",
        initcap(trim(col("status")))
    )

    .withColumn(
        "start_time",
        to_timestamp("start_time")
    )

    .withColumn(
        "end_time",
        to_timestamp("end_time")
    )

    .withColumn(
        "silver_load_timestamp",
        current_timestamp()
    )

)

write_silver(step_status,"onboarding_step_status")

# ============================================================
# CUSTOMER_DOCUMENT
# ============================================================

print("Transforming customer_document...")

customer_document = read_bronze("customer_document")

customer_document = (

    customer_document

    .dropDuplicates(
        [
            "application_id",
            "document_type",
            "document_version"
        ]
    )

    .withColumn(
        "document_type",
        upper(trim(col("document_type")))
    )

    .withColumn(
        "upload_status",
        initcap(trim(col("upload_status")))
    )

    .withColumn(
        "verification_status",
        initcap(trim(col("verification_status")))
    )

    .withColumn(
        "uploaded_time",
        to_timestamp("uploaded_time")
    )

    .withColumn(
        "document_version",
        col("document_version").cast("int")
    )

    .withColumn(
        "created_at",
        to_timestamp("created_at")
    )

    .withColumn(
        "updated_at",
        to_timestamp("updated_at")
    )

    .withColumn(
        "silver_load_timestamp",
        current_timestamp()
    )

)

write_silver(customer_document, "customer_document")

# ============================================================
# CUSTOMER_BANK
# ============================================================

print("Transforming customer_bank...")

customer_bank = read_bronze("customer_bank")

customer_bank = (

    customer_bank

    .dropDuplicates(["bank_id"])

    .withColumn(
        "bank_name",
        initcap(trim(col("bank_name")))
    )

    .withColumn(
        "ifsc",
        upper(trim(col("ifsc")))
    )

    .withColumn(
        "verification_status",
        initcap(trim(col("verification_status")))
    )

    .withColumn(
        "created_at",
        to_timestamp("created_at")
    )

    .withColumn(
        "updated_at",
        to_timestamp("updated_at")
    )

    .withColumn(
        "silver_load_timestamp",
        current_timestamp()
    )

)

write_silver(customer_bank,"customer_bank")

# ============================================================
# CUSTOMER_VERIFICATION_STATUS
# ============================================================

print("Transforming customer_verification_status...")

customer_verification_status = read_bronze("customer_verification_status")

verification = customer_verification_status

verification = (

    verification

    .dropDuplicates(["verification_id"])

    .withColumn(
        "overall_status",
        initcap(trim(col("overall_status")))
    )

    .withColumn(
        "mobile_status",
        initcap(trim(col("mobile_status")))
    )

    .withColumn(
        "email_status",
        initcap(trim(col("email_status")))
    )

    .withColumn(
        "pan_status",
        initcap(trim(col("pan_status")))
    )

    .withColumn(
        "aadhaar_status",
        initcap(trim(col("aadhaar_status")))
    )

    .withColumn(
        "address_status",
        initcap(trim(col("address_status")))
    )

    .withColumn(
        "bank_status",
        initcap(trim(col("bank_status")))
    )

    .withColumn(
        "document_status",
        initcap(trim(col("document_status")))
    )

    .withColumn(
        "last_updated",
        to_timestamp("last_updated")
    )

    .withColumn(
        "created_at",
        to_timestamp("created_at")
    )

    .withColumn(
        "updated_at",
        to_timestamp("updated_at")
    )

    .withColumn(
        "created_at",
        when(
            col("created_at").isNull(),
            col("updated_at")
        ).otherwise(col("created_at"))
    )

    .withColumn(
        "silver_load_timestamp",
        current_timestamp()
    )

)

write_silver(
    verification,
    "customer_verification_status"
)

# ============================================================
# COMPLIANCE_REVIEW
# ============================================================

print("Transforming compliance_review...")

compliance_review = read_bronze("compliance_review")

compliance_review = (

    compliance_review

    .dropDuplicates(["review_id"])

    .withColumn(
        "decision",
        initcap(trim(col("decision")))
    )

    .withColumn(
        "review_comment",
        trim(col("review_comment"))
    )

    .withColumn(
        "reviewed_by",
        trim(col("reviewed_by"))
    )

    .withColumn(
        "review_date",
        to_timestamp("review_date")
    )

    .withColumn(
        "created_at",
        to_timestamp("created_at")
    )

    .withColumn(
        "updated_at",
        to_timestamp("updated_at")
    )

    .withColumn(
        "silver_load_timestamp",
        current_timestamp()
    )

)

write_silver(compliance_review, "compliance_review")

# ============================================================
# ACTIVATION
# ============================================================

print("Transforming activation...")

activation = read_bronze("activation")

activation = (

    activation

    .dropDuplicates(["activation_id"])

    .withColumn(
        "activation_status",
        initcap(trim(col("activation_status")))
    )

    .withColumn(
        "created_at",
        to_timestamp("created_at")
    )

    .withColumn(
        "updated_at",
        to_timestamp("updated_at")
    )

    .withColumn(
        "silver_load_timestamp",
        current_timestamp()
    )
    
    .withColumn(
        "activation_time",
        to_timestamp("activation_time")
    )
    
    .withColumn(
        "trading_enabled",
        when(
            lower(col("trading_enabled")).isin("true","yes","1"),
            True
        ).otherwise(False)
    )

)

write_silver(activation,"activation")

# ============================================================
# CUSTOMER_EVENT
# ============================================================

print("Transforming customer_event...")

customer_event = read_bronze("customer_event")

customer_event = (

    customer_event

    .dropDuplicates(["event_id"])

    .withColumn(
        "event_name",
        initcap(trim(col("event_name")))
    )

    .withColumn(
        "event_source",
        initcap(trim(col("event_source")))
    )

    .withColumn(
        "event_time",
        to_timestamp("event_time")
    )

    .withColumn(
        "customer_id",
        trim(col("customer_id"))
    )

    .withColumn(
        "application_id",
        trim(col("application_id"))
    )

    .withColumn(
        "silver_load_timestamp",
        current_timestamp()
    )

)

write_silver(customer_event,"customer_event")

# ============================================================
# MAIN EXECUTION
# ============================================================

print("=" * 70)
print("Starting Bronze → Silver ETL")
print("=" * 70)

print("Processing Customer...")
# Customer
# (Section 6)

print("Processing Customer Address...")
# Customer Address
# (Section 7)

print("Processing Onboarding Application...")
# Application
# (Section 8)

print("Processing Step Master...")
# Step Master
# (Section 9)

print("Processing Step Status...")
# Step Status
# (Section 10)

print("Processing Customer Document...")
# Document
# (Section 11)

print("Processing Customer Bank...")
# Bank
# (Section 12)

print("Processing Verification Status...")
# Verification
# (Section 13)

print("Processing Compliance Review...")
# Review
# (Section 14)

print("Processing Activation...")
# Activation
# (Section 15)

print("Processing Customer Event...")
# Event
# (Section 16)

print("=" * 70)
print("Silver Layer Successfully Created")
print("=" * 70)

job.commit()

