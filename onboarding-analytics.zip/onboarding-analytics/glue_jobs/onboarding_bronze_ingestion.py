import sys
import boto3
import re
from datetime import datetime

from pyspark.context import SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col,
    trim,
    when,
    lit,
    current_timestamp,
    input_file_name
)

from awsglue.context import GlueContext
from awsglue.job import Job

sc = SparkContext()

glueContext = GlueContext(sc)

spark = glueContext.spark_session

job = Job(glueContext)
job.init("bronze_etl", {})

S3_BUCKET = "onboarding-raw-data"

RAW_PREFIX = "raw"

JDBC_URL = "jdbc:postgresql://onboarding-postgres.cpckkgcwoy32.ap-south-1.rds.amazonaws.com:5432/onboarding_analytics_db"

DB_HOST = "onboarding-postgres.cpckkgcwoy32.ap-south-1.rds.amazonaws.com"

DB_PORT = 5432

DB_NAME = "onboarding_analytics_db"

DB_USER = "postgres"

DB_PASSWORD = "Incedo123"

BRONZE_SCHEMA = "bronze"

TABLES = {
    "customer": "customer",
    "customer_address": "customer_address",
    "onboarding_application": "onboarding_application",
    "onboarding_step_master": "onboarding_step_master",
    "onboarding_step_status": "onboarding_step_status",
    "customer_document": "customer_document",
    "customer_bank": "customer_bank",
    "customer_verification_status": "customer_verification_status",
    "compliance_review": "compliance_review",
    "activation": "activation",
    "customer_event": "customer_event"
}

def clean_column_name(column):

    column = column.lower()

    column = column.strip()

    column = re.sub(r"[^a-z0-9_]", "_", column)

    column = re.sub(r"_+", "_", column)

    return column
    
def clean_dataframe(df):

    for c in df.columns:

        new_name = clean_column_name(c)

        df = df.withColumnRenamed(c, new_name)

    for c in df.columns:

        df = df.withColumn(

            c,

            when(trim(col(c)) == "", None)

            .otherwise(trim(col(c)))

        )

    df = df.withColumn(

        "ingestion_timestamp",

        current_timestamp()

    )

    df = df.withColumn(

        "source_file",

        input_file_name()

    )

    return df

def read_csv_from_s3(folder_name):

    path = f"s3://{S3_BUCKET}/{RAW_PREFIX}/{folder_name}/"

    print(f"Reading : {path}")

    df = (
        spark.read
        .option("header", "true")
        .option("multiLine", "true")
        .option("escape", "\"")
        .option("quote", "\"")
        .csv(path)
    )

    return clean_dataframe(df)

def write_to_bronze(df, table_name):

    print(f"Loading Bronze Table : {table_name}")

    (
        df.write
        .format("jdbc")
        .option("url", JDBC_URL)
        .option("driver", "org.postgresql.Driver")
        .option("dbtable", f"{BRONZE_SCHEMA}.{table_name}")
        .option("user", DB_USER)
        .option("password", DB_PASSWORD)
        .mode("overwrite")
        .save()
    )

    print(f"Finished : {table_name}")
    
def log_summary(table_name, df):

    print("===================================")
    print(f"Table Loaded : {table_name}")
    print(f"Rows Loaded  : {df.count()}")
    print("===================================")

print("==========================================")
print("Starting Bronze ETL")
print("==========================================")

for folder_name, table_name in TABLES.items():

    try:

        print(f"\nProcessing {folder_name}")

        df = read_csv_from_s3(folder_name)

        log_summary(table_name, df)

        write_to_bronze(df, table_name)

        print(f"{table_name} loaded successfully.")

    except Exception as e:

        print(f"Failed loading {table_name}")

        print(str(e))

print("==========================================")
print("Bronze ETL Completed")
print("==========================================")

job.commit()